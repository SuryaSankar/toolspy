from setuptools import setup

setup(
    name='pyutils',
    version='0.1.0',
    long_description='A python toolset',
    packages=['pyutils'],
    include_package_data=True,
    license='MIT',
    author='SuryaSankar',
    author_email='suryashankar.m@gmail.com')
